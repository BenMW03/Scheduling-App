D969 WGU C# Scheduling Application by Benjamin Weiglein

Setup Instructions

===================================

Requirements:
- Visual Studio 2019 or later (.NET Framework 4.8)
- MySQL Server 8.0
- MySql.Data NuGet package (v9.6.0)

Database Setup:
1. Install MySQL Server 8.0
2. Open MySQL Workbench
3. Run the included database_setup.sql script
4. This will create the database, tables, and sample data automatically

Connection Settings:
- The app connects to MySQL using these default settings:
  Server:   localhost
  Port:     3306
  Database: client_schedule
  Username: sqlUser
  Password: Passw0rd!

- If your MySQL credentials differ, update Data/DBConnection.cs

Login:
- Username: test
- Password: test

===================================