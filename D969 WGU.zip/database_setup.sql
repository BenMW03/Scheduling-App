-- SchedulingApp Database Setup Script
-- Run this script in MySQL Workbench

-- Step 1: Create and select the database

CREATE DATABASE IF NOT EXISTS client_schedule;
USE client_schedule;

-- Step 2: Create tables

CREATE TABLE IF NOT EXISTS country (
    countryId INT NOT NULL AUTO_INCREMENT,
    country VARCHAR(50) NOT NULL,
    createDate DATETIME NOT NULL,
    createdBy VARCHAR(40) NOT NULL,
    lastUpdate TIMESTAMP NOT NULL,
    lastUpdateBy VARCHAR(40) NOT NULL,
    PRIMARY KEY (countryId)
);

CREATE TABLE IF NOT EXISTS city (
    cityId INT NOT NULL AUTO_INCREMENT,
    city VARCHAR(50) NOT NULL,
    countryId INT NOT NULL,
    createDate DATETIME NOT NULL,
    createdBy VARCHAR(40) NOT NULL,
    lastUpdate TIMESTAMP NOT NULL,
    lastUpdateBy VARCHAR(40) NOT NULL,
    PRIMARY KEY (cityId),
    FOREIGN KEY (countryId) REFERENCES country(countryId)
);

CREATE TABLE IF NOT EXISTS address (
    addressId INT NOT NULL AUTO_INCREMENT,
    address VARCHAR(50) NOT NULL,
    address2 VARCHAR(50) NOT NULL,
    cityId INT NOT NULL,
    postalCode VARCHAR(10) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    createDate DATETIME NOT NULL,
    createdBy VARCHAR(40) NOT NULL,
    lastUpdate TIMESTAMP NOT NULL,
    lastUpdateBy VARCHAR(40) NOT NULL,
    PRIMARY KEY (addressId),
    FOREIGN KEY (cityId) REFERENCES city(cityId)
);

CREATE TABLE IF NOT EXISTS customer (
    customerId INT NOT NULL AUTO_INCREMENT,
    customerName VARCHAR(45) NOT NULL,
    addressId INT NOT NULL,
    active TINYINT(1) NOT NULL,
    createDate DATETIME NOT NULL,
    createdBy VARCHAR(40) NOT NULL,
    lastUpdate TIMESTAMP NOT NULL,
    lastUpdateBy VARCHAR(40) NOT NULL,
    PRIMARY KEY (customerId),
    FOREIGN KEY (addressId) REFERENCES address(addressId)
);

CREATE TABLE IF NOT EXISTS user (
    userId INT NOT NULL AUTO_INCREMENT,
    userName VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL,
    active TINYINT NOT NULL,
    createDate DATETIME NOT NULL,
    createdBy VARCHAR(40) NOT NULL,
    lastUpdate TIMESTAMP NOT NULL,
    lastUpdateBy VARCHAR(40) NOT NULL,
    PRIMARY KEY (userId)
);

CREATE TABLE IF NOT EXISTS appointment (
    appointmentId INT NOT NULL AUTO_INCREMENT,
    customerId INT NOT NULL,
    userId INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    location TEXT NOT NULL,
    contact TEXT NOT NULL,
    type TEXT NOT NULL,
    url VARCHAR(255) NOT NULL,
    start DATETIME NOT NULL,
    end DATETIME NOT NULL,
    createDate DATETIME NOT NULL,
    createdBy VARCHAR(40) NOT NULL,
    lastUpdate TIMESTAMP NOT NULL,
    lastUpdateBy VARCHAR(40) NOT NULL,
    PRIMARY KEY (appointmentId),
    FOREIGN KEY (customerId) REFERENCES customer(customerId),
    FOREIGN KEY (userId) REFERENCES user(userId)
);

-- Step 3: Insert test user (username: test, password: test)

INSERT INTO user (userName, password, active, createDate, createdBy, lastUpdate, lastUpdateBy)
VALUES ('test', 'test', 1, NOW(), 'admin', NOW(), 'admin');

-- Step 4: Insert sample data

INSERT INTO country (country, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES
('United States', NOW(), 'admin', NOW(), 'admin'),
('United Kingdom', NOW(), 'admin', NOW(), 'admin');

INSERT INTO city (city, countryId, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES
('Phoenix', 1, NOW(), 'admin', NOW(), 'admin'),
('New York', 1, NOW(), 'admin', NOW(), 'admin'),
('London', 2, NOW(), 'admin', NOW(), 'admin');

INSERT INTO address (address, address2, cityId, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES
('123 Main St', '', 1, '85001', '555-123-4567', NOW(), 'admin', NOW(), 'admin'),
('456 Broadway', '', 2, '10001', '555-234-5678', NOW(), 'admin', NOW(), 'admin'),
('789 Oxford St', '', 3, 'W1C 1', '555-345-6789', NOW(), 'admin', NOW(), 'admin');

INSERT INTO customer (customerName, addressId, active, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES
('John Smith', 1, 1, NOW(), 'admin', NOW(), 'admin'),
('Jane Doe', 2, 1, NOW(), 'admin', NOW(), 'admin'),
('James Brown', 3, 1, NOW(), 'admin', NOW(), 'admin');

INSERT INTO appointment (customerId, userId, title, description, location, contact, type, url, start, end, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES
(1, 1, 'Initial Consultation', 'First meeting with client', 'Phoenix', 'John Smith', 'Consultation', '', DATE_ADD(CURDATE(), INTERVAL 1 DAY) + INTERVAL 14 HOUR, DATE_ADD(CURDATE(), INTERVAL 1 DAY) + INTERVAL 15 HOUR, NOW(), 'test', NOW(), 'test'),
(2, 1, 'Follow Up Meeting', 'Follow up on previous consultation', 'New York', 'Jane Doe', 'Follow-up', '', DATE_ADD(CURDATE(), INTERVAL 2 DAY) + INTERVAL 15 HOUR, DATE_ADD(CURDATE(), INTERVAL 2 DAY) + INTERVAL 16 HOUR, NOW(), 'test', NOW(), 'test'),
(3, 1, 'Strategy Session', 'Quarterly strategy review', 'London', 'James Brown', 'Strategy', '', DATE_ADD(CURDATE(), INTERVAL 3 DAY) + INTERVAL 14 HOUR, DATE_ADD(CURDATE(), INTERVAL 3 DAY) + INTERVAL 15 HOUR, NOW(), 'test', NOW(), 'test'),
(1, 1, 'Project Review', 'Review project milestones', 'Phoenix', 'John Smith', 'Consultation', '', DATE_ADD(CURDATE(), INTERVAL 7 DAY) + INTERVAL 18 HOUR, DATE_ADD(CURDATE(), INTERVAL 7 DAY) + INTERVAL 19 HOUR, NOW(), 'test', NOW(), 'test'),
(2, 1, 'Budget Planning', 'Annual budget discussion', 'New York', 'Jane Doe', 'Planning', '', DATE_ADD(CURDATE(), INTERVAL 8 DAY) + INTERVAL 15 HOUR, DATE_ADD(CURDATE(), INTERVAL 8 DAY) + INTERVAL 16 HOUR, NOW(), 'test', NOW(), 'test');